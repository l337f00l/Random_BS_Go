Both of these blocks were made by Rabees. Feel free to take them and alter the code, but I don't see
why'd you'd want to, seeing how they're so simple. Best if set to act like tile 25 or 130. Credit not necessary,
but it would give me a warm feeling inside.