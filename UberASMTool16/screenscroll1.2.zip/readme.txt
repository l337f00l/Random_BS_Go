For best results, you will probably want to combine with the Sprite Scroll Fix patch found here:
 https://www.smwcentral.net/?p=section&a=details&id=13675
Without this patch, sprites may not spawn when moving the screen left.

If you decide you do not want this UberASM anymore, make sure to also apply the remove.asm patch after removing the code from UberASM Tool's list or the game will crash.