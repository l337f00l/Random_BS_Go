## Retry System

This patch is meant as a spiritual successor to worldpeace's [Retry patch](https://www.smwcentral.net/?p=section&a=details&id=26078). While having the same functionalities, it features cleaner and more documented code, new features and a lot less hijacks, which makes it compatible with much more patches than before. Requires [UberASM Tool v1.4](https://www.smwcentral.net/?p=section&a=details&id=19982).
