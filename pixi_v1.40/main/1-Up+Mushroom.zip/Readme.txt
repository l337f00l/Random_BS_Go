~1-Up+Mushroom disassembly~
This is disassembly od sprites 74 and 78 in SMW - Mushroom and 1-Up.

Comes with some options and features. It uses Lunar Magic's Extra Byte to set it's initial behavor.
It can initially blink-fall, rise up, and move no matter it's initially blocked or not. For more details check .ASM file.
By RussianMan. Credit is optional.