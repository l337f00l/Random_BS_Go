ExGFX80.bin = BG1

Page to load BG Map16 for Sample Level: 43
