Custom Grassland ExGFX (Version 1.1) - by I8Strudel

Please give credit if used!

Special thanks to Broozer for noticing a critical error in Version 1.0!