Donut stars FG tileset by Schieber1234,
based off the original donut bridge.
Credit not necessary, but would be pretty nice. ;)
Looks best with a few more map 16 edits.
This is my first ExGFX.
Have fun!